package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.AssetDao
import com.example.data.local.dao.CustomerDao
import com.example.data.local.dao.InstallmentDao
import com.example.data.local.dao.InstallmentPaymentDao
import com.example.data.local.dao.InstallmentPlanDao
import com.example.data.local.dao.SyncMetadataDao
import com.example.data.local.entity.AssetEntity
import com.example.data.local.entity.CustomerEntity
import com.example.data.local.entity.InstallmentPaymentEntity
import com.example.data.local.entity.InstallmentPlanEntity
import com.example.data.local.entity.SyncMetadataEntity

@Database(
    entities = [
        CustomerEntity::class,
        InstallmentPlanEntity::class,
        InstallmentPaymentEntity::class,
        SyncMetadataEntity::class,
        AssetEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun installmentDao(): InstallmentDao
    abstract fun customerDao(): CustomerDao
    abstract fun installmentPlanDao(): InstallmentPlanDao
    abstract fun installmentPaymentDao(): InstallmentPaymentDao
    abstract fun syncMetadataDao(): SyncMetadataDao
    abstract fun assetDao(): AssetDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        /** v2 -> v3: adds the assets library table. Non-destructive; existing data is untouched. */
        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `pess_assets` (" +
                        "`id` TEXT NOT NULL, `kind` TEXT NOT NULL, `name` TEXT NOT NULL, " +
                        "`fileName` TEXT NOT NULL, `mimeType` TEXT NOT NULL, " +
                        "`sizeBytes` INTEGER NOT NULL, `widthPx` INTEGER NOT NULL, " +
                        "`heightPx` INTEGER NOT NULL, `archived` INTEGER NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL, PRIMARY KEY(`id`))"
                )
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "installment_manager.db"
                )
                    .addMigrations(MIGRATION_2_3)
                    // Never delete user data when a schema change is missing. A missing
                    // migration must fail visibly so it can be handled by a tested migration
                    // or an explicit recovery flow instead of silently dropping all tables.
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
