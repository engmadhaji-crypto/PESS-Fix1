package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Metadata of an image asset (logo / stamp / signature). The image file lives in filesDir. */
@Entity(tableName = "pess_assets")
data class AssetEntity(
    @PrimaryKey val id: String,
    val kind: String,
    val name: String,
    val fileName: String,
    val mimeType: String,
    val sizeBytes: Long,
    val widthPx: Int,
    val heightPx: Int,
    val archived: Boolean,
    val createdAt: Long
)
