package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.assets.AssetKind
import com.example.data.local.entity.AssetEntity

/**
 * Lets the user pick, for this statement only, which logo / stamp / signature to print.
 * Nothing is pre-selected, so no image is printed unless the user chooses it.
 */
@Composable
fun StatementOptionsDialog(
    assets: List<AssetEntity>,
    onImportAsset: (Uri, AssetKind) -> Unit,
    onDismiss: () -> Unit,
    onConfirm: (logoId: String?, stampId: String?, signId: String?) -> Unit
) {
    var logoId by remember { mutableStateOf<String?>(null) }
    var stampId by remember { mutableStateOf<String?>(null) }
    var signId by remember { mutableStateOf<String?>(null) }
    var pendingKind by remember { mutableStateOf<AssetKind?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        val kind = pendingKind
        if (uri != null && kind != null) onImportAsset(uri, kind)
        pendingKind = null
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("خيارات كشف الحساب") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                AssetPickerRow(
                    kind = AssetKind.LOGO,
                    assets = assets,
                    selectedId = logoId,
                    onSelect = { logoId = it },
                    onAdd = { pendingKind = AssetKind.LOGO; picker.launch("image/*") }
                )
                AssetPickerRow(
                    kind = AssetKind.STAMP,
                    assets = assets,
                    selectedId = stampId,
                    onSelect = { stampId = it },
                    onAdd = { pendingKind = AssetKind.STAMP; picker.launch("image/*") }
                )
                AssetPickerRow(
                    kind = AssetKind.SIGN,
                    assets = assets,
                    selectedId = signId,
                    onSelect = { signId = it },
                    onAdd = { pendingKind = AssetKind.SIGN; picker.launch("image/*") }
                )
                Text(
                    "الصور بصيغة PNG بحد أقصى 2 ميجابايت و2400 بكسل، وتُحفظ في مكتبة التطبيق.",
                    style = MaterialTheme.typography.bodySmall
                )
            }
        },
        confirmButton = {
            Button(onClick = { onConfirm(logoId, stampId, signId) }) { Text("إنشاء PDF") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("إلغاء") } }
    )
}

@Composable
private fun AssetPickerRow(
    kind: AssetKind,
    assets: List<AssetEntity>,
    selectedId: String?,
    onSelect: (String?) -> Unit,
    onAdd: () -> Unit
) {
    val ofKind = assets.filter { it.kind == kind.name }
    Column(Modifier.fillMaxWidth()) {
        Text(kind.labelAr, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Row(
            modifier = Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = selectedId == null,
                onClick = { onSelect(null) },
                label = { Text("بدون") }
            )
            ofKind.forEach { asset ->
                FilterChip(
                    selected = selectedId == asset.id,
                    onClick = { onSelect(asset.id) },
                    label = { Text(asset.name) }
                )
            }
            TextButton(onClick = onAdd) { Text("+ إضافة") }
        }
    }
}
