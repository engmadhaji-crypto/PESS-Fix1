package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.AssetEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AssetDao {
    @Query("SELECT * FROM pess_assets WHERE archived = 0 ORDER BY createdAt DESC")
    fun observeActive(): Flow<List<AssetEntity>>

    @Query("SELECT * FROM pess_assets WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): AssetEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(asset: AssetEntity)

    @Query("UPDATE pess_assets SET archived = :archived WHERE id = :id")
    suspend fun setArchived(id: String, archived: Boolean)
}
