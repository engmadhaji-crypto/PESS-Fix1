package com.example.data.local.backup

import com.example.domain.util.InstallmentCalculator
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import kotlin.math.roundToLong

/**
 * Converts a PESS "Backup v2" file (customers / contracts / phones / ledger) into the app's
 * Room-based [DatabaseBackupPayload]. Raw v2 amounts are integer minor units (x100): they are
 * divided by 100 exactly once here. No dates or values are invented:
 *  - an unknown date stays 0 (shown as an empty string and never treated as overdue);
 *  - the ledger is allocated over the contract installments in order; excess is kept in notes;
 *  - company, assets, decisions and audit have no Room model and are not imported.
 */
object BackupV2Converter {

    private val parser = Json { ignoreUnknownKeys = true }

    fun looksLikeV2(rawJson: String): Boolean = runCatching {
        val root = parser.parseToJsonElement(rawJson).jsonObject
        root["v"]?.jsonPrimitive?.intOrNull == 2 &&
            root["contracts"] is JsonArray && root["customers"] is JsonArray
    }.getOrDefault(false)

    fun convert(rawJson: String): DatabaseBackupPayload {
        val root = parser.parseToJsonElement(rawJson).jsonObject
        val customersJson = root.array("customers")
        val contractsJson = root.array("contracts")
        val phonesJson = root.array("phones")
        val ledgerJson = root.array("ledger")

        val phonesByCustomer = phonesJson.groupBy { it.obj().long("customer_id") }
        val ledgerByContract = ledgerJson
            .sortedBy { it.obj().long("id") ?: 0L }
            .groupBy { it.obj().long("contract_id") }

        val customers = customersJson.mapNotNull { el ->
            val o = el.obj()
            val id = o.long("id") ?: return@mapNotNull null
            val name = o.str("name").trim()
            if (name.isEmpty()) return@mapNotNull null
            val phones = phonesByCustomer[id].orEmpty().map { it.obj() }
            val first = phones.firstOrNull()?.str("number")?.trim().orEmpty()
            val others = phones.drop(1).joinToString("، ") {
                val label = it.str("label").trim()
                val number = it.str("number").trim()
                if (label.isEmpty()) number else "$label: $number"
            }
            val created = parseIso(o.str("created_at"))
            CustomerBackupDto(
                id = "v2-c-$id",
                fullName = name,
                phone = first,
                notes = if (others.isEmpty()) "" else "أرقام أخرى: $others",
                createdAt = created,
                updatedAt = created
            )
        }
        val customerIds = customers.map { it.id }.toSet()

        val plans = ArrayList<PlanBackupDto>()
        val installments = ArrayList<InstallmentBackupDto>()

        for (el in contractsJson) {
            val c = el.obj()
            val contractId = c.long("id") ?: continue
            val customerId = "v2-c-${c.long("customer_id")}"
            if (customerId !in customerIds) continue

            val planId = "v2-k-$contractId"
            val created = parseIso(c.str("created_at"))
            val total = c.num("total") / 100.0
            val discount = c.num("discount") / 100.0
            val down = c.num("down") / 100.0
            val rawCost = c.num("cost") / 100.0
            val startMillis = parseDay(c.str("date"))
            val firstDueMillis = parseDay(c.str("due"))
            val financedCents = maxOf(0L, (c.num("total") - c.num("discount") - c.num("down")).roundToLong())
            val count = maxOf(1, c.long("months")?.toInt() ?: 0)

            val entries = ledgerByContract[contractId].orEmpty().map { it.obj() }
            val payEntries = entries.filter {
                val k = it.str("kind"); k == "pay" || k == "reversal"
            }
            val netCents = payEntries.sumOf { it.num("amount").roundToLong() }

            // Cumulative net after each payment/reversal entry, used to find the completion date.
            var running = 0L
            val cumulative = payEntries.map { e ->
                running += e.num("amount").roundToLong()
                running to e.str("date")
            }

            val base = financedCents / count
            val dueCents = LongArray(count) { base }
            dueCents[count - 1] = financedCents - base * (count - 1)

            var remaining = maxOf(0L, netCents)
            var cumDue = 0L
            var allPaid = true
            val lastMethod = payEntries.lastOrNull()?.str("method").orEmpty().trim()
            val lastDate = payEntries.lastOrNull { it.str("date").isNotBlank() }?.str("date").orEmpty()

            for (index in 0 until count) {
                val due = dueCents[index]
                val paid = minOf(remaining, due)
                remaining -= paid
                cumDue += due
                val fullyPaid = paid >= due
                if (!fullyPaid) allPaid = false
                val status = when {
                    fullyPaid -> "PAID"
                    paid > 0L -> "PARTIAL"
                    else -> "PENDING"
                }
                val paidDate = when {
                    paid <= 0L -> 0L
                    fullyPaid -> parseDay(cumulative.firstOrNull { it.first >= cumDue }?.second.orEmpty())
                    else -> parseDay(lastDate)
                }
                val dueDate = if (firstDueMillis > 0L) {
                    InstallmentCalculator.addMonths(firstDueMillis, index)
                } else {
                    0L
                }
                installments += InstallmentBackupDto(
                    id = "v2-i-$contractId-${index + 1}",
                    planId = planId,
                    customerId = customerId,
                    installmentNumber = index + 1,
                    dueDateMillis = dueDate,
                    amountDue = due / 100.0,
                    amountPaid = paid / 100.0,
                    paidDateMillis = if (paidDate > 0L) paidDate else null,
                    status = status,
                    paymentMethod = mapMethod(lastMethod),
                    notes = if (paid > 0L && lastMethod.isNotEmpty()) "طريقة الدفع: $lastMethod" else "",
                    updatedAt = created
                )
            }

            val noteParts = ArrayList<String>()
            c.str("type").trim().takeIf { it.isNotEmpty() }?.let { noteParts += "النوع: $it" }
            c.str("sub").trim().takeIf { it.isNotEmpty() }?.let { noteParts += "فرعي: $it" }
            if (discount > 0.0) noteParts += "خصم: ${InstallmentCalculator.formatCurrency(discount)}"
            if (rawCost > 0.0) noteParts += "التكلفة: ${InstallmentCalculator.formatCurrency(rawCost)}"
            if (remaining > 0L) noteParts += "مدفوع زائد عن المطلوب: ${InstallmentCalculator.formatCurrency(remaining / 100.0)}"
            if (c.long("months") == 0L) noteParts += "عقد نقدي (بدون أقساط شهرية)"

            plans += PlanBackupDto(
                id = planId,
                customerId = customerId,
                itemName = c.str("items").trim().ifEmpty { "عقد رقم $contractId" },
                totalCashPrice = total,
                downPayment = down,
                interestRatePercent = 0.0,
                financedTotal = financedCents / 100.0,
                installmentCount = count,
                intervalMonths = 1,
                startDateMillis = startMillis,
                status = if (allPaid) "COMPLETED" else "ACTIVE",
                notes = noteParts.joinToString(" | "),
                createdAt = created,
                updatedAt = created
            )
        }

        return DatabaseBackupPayload(
            schemaVersion = DatabaseBackupPayload.CURRENT_SCHEMA_VERSION,
            exportedAtMillis = System.currentTimeMillis(),
            customers = customers,
            plans = plans,
            installments = installments
        )
    }

    private fun mapMethod(method: String): String = when (method.trim()) {
        "", "نقداً", "نقدا", "نقد" -> "CASH"
        else -> "BANK_TRANSFER"
    }

    private fun parseIso(value: String): Long {
        if (value.isBlank()) return 0L
        val formats = listOf("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'")
        for (pattern in formats) {
            val fmt = SimpleDateFormat(pattern, Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
            val parsed = runCatching { fmt.parse(value)?.time }.getOrNull()
            if (parsed != null) return parsed
        }
        return 0L
    }

    private fun parseDay(value: String): Long {
        if (value.isBlank()) return 0L
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        return runCatching { fmt.parse(value.trim())?.time }.getOrNull() ?: 0L
    }

    private fun JsonObject.array(key: String): List<JsonElement> =
        (this[key] as? JsonArray)?.toList().orEmpty()

    private fun JsonElement.obj(): JsonObject = this.jsonObject

    private fun JsonObject.str(key: String): String {
        val p = this[key] as? JsonPrimitive ?: return ""
        return if (p.isString) p.content else p.content.takeIf { it != "null" }.orEmpty()
    }

    private fun JsonObject.long(key: String): Long? = (this[key] as? JsonPrimitive)?.longOrNull

    private fun JsonObject.num(key: String): Double = (this[key] as? JsonPrimitive)?.doubleOrNull ?: 0.0
}
