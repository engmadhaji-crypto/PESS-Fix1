package com.example.data.assets

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.example.data.local.dao.AssetDao
import com.example.data.local.entity.AssetEntity
import com.example.data.pdf.StatementAssets
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.jsonObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

enum class AssetKind(val labelAr: String) {
    LOGO("الشعار"),
    STAMP("الختم"),
    SIGN("التوقيع")
}

/**
 * Asset library: images are normalised to PNG, at most 2400px on the longest side and at most
 * 2 MB each, then stored as files in filesDir/pess_assets (Room keeps only the metadata, because a
 * 2 MB blob can exceed the SQLite cursor window).
 */
class AssetRepository(
    private val context: Context,
    private val dao: AssetDao
) {
    companion object {
        const val MAX_BYTES = 2L * 1024L * 1024L
        const val MAX_DIMENSION = 2400
        private const val MAX_SOURCE_BYTES = 20L * 1024L * 1024L
        private const val PDF_MAX_SIDE = 800
    }

    val assets: Flow<List<AssetEntity>> = dao.observeActive()

    private val storageDir: File
        get() = File(context.filesDir, "pess_assets").apply { mkdirs() }

    suspend fun importFromUri(uri: Uri, kind: AssetKind, displayName: String): Result<AssetEntity> =
        withContext(Dispatchers.IO) {
            runCatching {
                val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
                    val out = ByteArrayOutputStream()
                    val buffer = ByteArray(16 * 1024)
                    var total = 0L
                    while (true) {
                        val read = input.read(buffer)
                        if (read < 0) break
                        total += read
                        require(total <= MAX_SOURCE_BYTES) { "الصورة كبيرة جداً" }
                        out.write(buffer, 0, read)
                    }
                    out.toByteArray()
                } ?: error("تعذّر قراءة الصورة")
                store(
                    bytes = bytes,
                    id = UUID.randomUUID().toString(),
                    kind = kind,
                    name = displayName.ifBlank { kind.labelAr },
                    archived = false,
                    createdAt = System.currentTimeMillis()
                )
            }
        }

    /** Imports the "assets" array of a PESS Backup v2 file. Returns the number of new assets. */
    suspend fun importFromV2(rawJson: String): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val root = Json.parseToJsonElement(rawJson).jsonObject
            val array = root["assets"] as? JsonArray ?: return@runCatching 0
            var imported = 0
            for (element in array) {
                val o = element as? JsonObject ?: continue
                val rawId = (o["id"] as? JsonPrimitive)?.content ?: continue
                val kind = when ((o["kind"] as? JsonPrimitive)?.content) {
                    "logo" -> AssetKind.LOGO
                    "stamp" -> AssetKind.STAMP
                    "sign" -> AssetKind.SIGN
                    else -> continue
                }
                val id = "v2-a-$rawId"
                if (dao.getById(id) != null) continue
                val data = (o["data"] as? JsonPrimitive)?.content ?: continue
                val base64 = data.substringAfter("base64,", "")
                if (base64.isEmpty()) continue
                val bytes = runCatching { Base64.decode(base64, Base64.DEFAULT) }.getOrNull() ?: continue
                val archived = (o["archived"] as? JsonPrimitive)?.booleanOrNull ?: false
                val name = (o["name"] as? JsonPrimitive)?.content.orEmpty().ifBlank { kind.labelAr }
                val stored = runCatching {
                    store(bytes, id, kind, name, archived, System.currentTimeMillis())
                }
                if (stored.isSuccess) imported++
            }
            imported
        }
    }

    suspend fun archive(id: String) = withContext(Dispatchers.IO) { dao.setArchived(id, true) }

    /** Loads the chosen assets as small bitmaps ready for PDF drawing. */
    suspend fun loadStatementAssets(
        logoId: String?,
        stampId: String?,
        signId: String?
    ): StatementAssets = withContext(Dispatchers.IO) {
        StatementAssets(
            logo = loadBitmap(logoId),
            stamp = loadBitmap(stampId),
            sign = loadBitmap(signId)
        )
    }

    private suspend fun loadBitmap(id: String?): Bitmap? {
        if (id == null) return null
        val asset = dao.getById(id) ?: return null
        val file = File(storageDir, asset.fileName)
        if (!file.exists()) return null
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= PDF_MAX_SIDE) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return BitmapFactory.decodeFile(file.absolutePath, options)
    }

    private suspend fun store(
        bytes: ByteArray,
        id: String,
        kind: AssetKind,
        name: String,
        archived: Boolean,
        createdAt: Long
    ): AssetEntity {
        require(bytes.isNotEmpty()) { "الملف فارغ" }
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "الملف ليس صورة صالحة" }

        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= MAX_DIMENSION) sample *= 2
        val decoded = BitmapFactory.decodeByteArray(
            bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample }
        ) ?: error("تعذّر فك ترميز الصورة")

        var scale = minOf(1f, MAX_DIMENSION.toFloat() / maxOf(decoded.width, decoded.height))
        var encoded: ByteArray? = null
        var finalWidth = decoded.width
        var finalHeight = decoded.height
        repeat(4) {
            if (encoded != null) return@repeat
            val w = maxOf(1, (decoded.width * scale).toInt())
            val h = maxOf(1, (decoded.height * scale).toInt())
            val bitmap = if (w == decoded.width && h == decoded.height) {
                decoded
            } else {
                Bitmap.createScaledBitmap(decoded, w, h, true)
            }
            val out = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            if (out.size() <= MAX_BYTES) {
                encoded = out.toByteArray()
                finalWidth = w
                finalHeight = h
            }
            if (bitmap !== decoded) bitmap.recycle()
            scale *= 0.75f
        }
        decoded.recycle()
        val result = encoded ?: error("تعذّر تصغير الصورة إلى أقل من 2 ميجابايت")

        val fileName = "$id.png"
        File(storageDir, fileName).writeBytes(result)
        val entity = AssetEntity(
            id = id,
            kind = kind.name,
            name = name,
            fileName = fileName,
            mimeType = "image/png",
            sizeBytes = result.size.toLong(),
            widthPx = finalWidth,
            heightPx = finalHeight,
            archived = archived,
            createdAt = createdAt
        )
        dao.upsert(entity)
        return entity
    }
}
