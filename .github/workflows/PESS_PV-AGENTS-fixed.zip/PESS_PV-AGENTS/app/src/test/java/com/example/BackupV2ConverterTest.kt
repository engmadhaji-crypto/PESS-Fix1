package com.example

import com.example.data.local.backup.BackupV2Converter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class BackupV2ConverterTest {

    private val sample = """
    {"v":2,
     "customers":[{"id":1,"name":"عميل","credit":0,"created_at":"2026-10-24T12:53:11.161Z"}],
     "phones":[{"id":1,"customer_id":1,"number":"771","label":"a"},{"id":2,"customer_id":1,"number":"772","label":"b"}],
     "contracts":[{"id":5,"customer_id":1,"sub":"","type":"تقسيط","items":"لوح","months":2,
        "total":100000,"discount":10000,"down":30000,"cost":0,"date":"","due":"","created_at":"2026-10-24T12:53:11.161Z"}],
     "ledger":[
       {"id":1,"contract_id":5,"kind":"down","amount":30000,"date":"","method":"","reverses_id":null},
       {"id":2,"contract_id":5,"kind":"pay","amount":40000,"date":"2026-10-02","method":"نقداً","reverses_id":null},
       {"id":3,"contract_id":5,"kind":"pay","amount":30000,"date":"2026-10-09","method":"الكريمي","reverses_id":null}]}
    """.trimIndent()

    @Test
    fun detectsV2Only() {
        assertTrue(BackupV2Converter.looksLikeV2(sample))
        assertFalse(BackupV2Converter.looksLikeV2("""{"schemaVersion":1}"""))
    }

    @Test
    fun convertsContractAndAllocatesPayments() {
        val payload = BackupV2Converter.convert(sample)
        assertEquals(1, payload.customers.size)
        assertEquals("771", payload.customers[0].phone)
        assertEquals(1, payload.plans.size)
        assertEquals(600.0, payload.plans[0].financedTotal, 0.001) // raw minor units /100: (100000-10000-30000)/100
        assertEquals(0L, payload.plans[0].startDateMillis)          // unknown date is not invented
        assertEquals(2, payload.installments.size)
        assertEquals(300.0, payload.installments[0].amountDue, 0.001)
        assertEquals(300.0, payload.installments[0].amountPaid, 0.001)
        assertEquals("PAID", payload.installments[0].status)
        // 700 paid on 600 financed -> 100 excess is recorded in notes, not lost silently
        assertTrue(payload.plans[0].notes.contains("زائد"))
        assertEquals("COMPLETED", payload.plans[0].status)
        assertNull(payload.installments[1].paidDateMillis.takeIf { it == 0L })
        assertEquals(0L, payload.installments[1].dueDateMillis)
    }
}
